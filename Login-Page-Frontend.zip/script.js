$(document).ready(function(){
    $('body').ripples({
        resolution: 500,
        dropRadius: 25,
        perturbance: 0.03,
        
    })
})